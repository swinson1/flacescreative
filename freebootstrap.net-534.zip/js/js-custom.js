document.addEventListener('DOMContentLoaded', function() {
  const toggleButton = document.getElementById('toggle-mobile-menu');
  const mainMenu = document.getElementById('main-menu');

  toggleButton.addEventListener('click', function(e) {
    e.preventDefault();
    mainMenu.classList.toggle('hidden');
  });
});

document.addEventListener('DOMContentLoaded', function () {

  const toggleLink = document.getElementById('toggle-link');
  const dropdownMenu = document.getElementById('dropdown-menu');

  // Debugging: Check if elements are correctly selected
  console.log('toggleLink:', toggleLink);
  console.log('dropdownMenu:', dropdownMenu);

  function toggleDropdown(event) {
    event.preventDefault(); // Prevent default link behavior
    if (dropdownMenu) {
      dropdownMenu.classList.toggle('hidden');
      dropdownMenu.classList.toggle('opacity-0');
      dropdownMenu.classList.toggle('invisible');
    }
  }

  function handleResize() {
    if (window.innerWidth <= 768) {
      if (dropdownMenu) {
        dropdownMenu.classList.add('hidden');
      }
    } else {
      if (dropdownMenu) {
        dropdownMenu.classList.remove('hidden');
      }
    }
  }

  // Initial check
  handleResize();

  // Event listeners
  if (toggleLink) {
    toggleLink.addEventListener('click', toggleDropdown);
  }
  window.addEventListener('resize', handleResize);
});



// document.addEventListener('DOMContentLoaded', function() {
//   var actionButtons = document.querySelectorAll('.pro-button, .membership-button');

//   actionButtons.forEach(function(button) {
//       button.addEventListener('click', function(e) {
//           var postId = this.getAttribute('data-post-id');
//           var type = this.getAttribute('data-type');

//           var xhr = new XMLHttpRequest();
//           var params = 'action=increment_click_count&post_id=' + postId + '&type=' + type;

//           xhr.open('POST', ajax_object.ajax_url, true);
//           xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
          
//           xhr.onload = function() {
//               if (xhr.status >= 200 && xhr.status < 400) {
//                   var response = JSON.parse(xhr.responseText);
//                   if (response.success) {
//                       console.log(type + ' count incremented. Current count: ' + response.data.count);
//                   } else {
//                       console.log('Failed to increment ' + type + ' count.');
//                   }
//               }
//           };

//           xhr.send(params);
//       });
//   });
// });



